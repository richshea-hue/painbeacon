# ForestPlanet — Campaign Launch Posts with Today’s Media

**Date:** Wednesday, June 10, 2026  
**Focus:** Launch-day posts only: Facebook, Instagram, and LinkedIn.

## Facebook / GoNegative Page

**Post by:** 12pm ET

**Copy:**

Something is changing at ForestPlanet. 🌱

We've been quietly funding some of the most cost-effective reforestation work on the planet — partnering with vetted organizations to plant trees at under 15 cents each. That's $1 for 6+ trees in the ground. Real trees, in real soil, in places that desperately need them.

Today, we're turning up the volume.

Over the next 90 days, we're sharing the stories behind the work — the forests being reborn, the communities being restored, and the science that makes trees the most powerful climate tool we have.

Welcome to the campaign. We're glad you're here. 💚

Ready to plant your first tree? Start at 👉 forestplanet.org/donate

**Selected visual:** `ready/facebook_campaign_anchor_madagascar_after_1200x628.jpg`

**Why this photo:** Use the restored Madagascar mangrove site as the campaign anchor. It directly supports the “forests being reborn” message and is sourced from ForestPlanet’s official Madagascar mangrove update, which notes that Eden Reforestation Projects supplied the photos.[^1]

**Alternate Facebook visual:** `ready/facebook_square_launch_planting_1080x1080.jpg`

Use the square alternate if Hank wants something more human and emotional for the GoNegative audience.

## Instagram / @forestplanetorg

**Post by:** 12pm ET

**Copy:**

The campaign starts today. 🌿

90 days. Three platforms. One mission: plant trees where they matter most, at under $0.15 each.

ForestPlanet funds large-scale reforestation around the world — wildlife habitat, soil restoration, carbon sequestration, and the communities that depend on all of it.

$1 plants 6 trees. Link in bio to start. 🌱

**Hashtags for first comment:**  
#ForestPlanet #CampaignLaunch #Reforestation #GoNegative #PlantTrees #ClimateAction #TreePlanting #EcoNonprofit #PlantHope #NatureRestoration #CarbonSequestration #WildlifeHabitat #SoilHealth #ForestForAll #ActNow #GreenEarth #EcoWarrior #ClimateHope #SustainableLiving #OneMission

**Selected visual:** `ready/instagram_launch_portrait_planting_1080x1350.jpg`

**Why this photo:** This is the strongest scroll-stopper for Instagram: warm light, young mangroves, active planting, and the Eden watermark. Excluding the blurred face, the image communicates restoration work clearly without making the person’s identity the focus.

**Photo-only alternate:** `ready/instagram_photo_only_planting_square_1080x1080.jpg`

Use the square photo-only alternate if the team wants the launch line to stay entirely in the caption rather than on the image.

**Optional Reel direction:** If ForestPlanet already has permission to repurpose Eden partner footage, use Eden’s “Planting Trees to Grow Forests” video as the most relevant official motion source.[^2] If permission is not clear, use it only as creative reference and rely on approved stills or a licensed stock clip. A fallback Pexels tree-planting clip is labeled free to download and free to use, but it should not be represented as a ForestPlanet/Eden project site.[^3]

## LinkedIn / ForestPlanet Company Page

**Post by:** 9am ET

**Copy:**

ForestPlanet plants trees at under $0.15 each. Today, we're starting to tell that story more loudly.

We've spent years building an efficient, low-overhead model for large-scale reforestation — channeling donations from businesses, individuals, and foundations to vetted partners operating in the places where trees bring the most benefit: degraded soil, collapsed watersheds, communities with nothing left after clear-cutting stripped everything away.

Over the next 90 days, we'll be sharing what that work actually looks like. The transformations. The numbers. The communities on the other side of restoration.

If your organization has been looking for an environmental commitment that is verifiable, high-impact, and efficient — we'd welcome a conversation.

👉 forestplanet.org

**Selected visual:** `ready/linkedin_before_after_madagascar_1200x627.jpg`

**Why this photo:** This before/after visual is the most professional and data-forward choice. It shows a 2008 versus 2020 Madagascar mangrove restoration comparison and reinforces the LinkedIn post’s focus on verifiable, high-impact outcomes.

**LinkedIn hashtags:**  
#Reforestation #CSR #ClimateAction #ESG #Nonprofit #Sustainability #ImpactInvesting

## Same-Day Media Checklist

| Task | Status |
|---|---|
| Facebook landscape image prepared | Ready: `facebook_campaign_anchor_madagascar_after_1200x628.jpg` |
| Instagram portrait image prepared | Ready: `instagram_launch_portrait_planting_1080x1350.jpg` |
| Instagram square alternate prepared | Ready: `instagram_photo_only_planting_square_1080x1080.jpg` |
| LinkedIn before/after image prepared | Ready: `linkedin_before_after_madagascar_1200x627.jpg` |
| Optional Reel source identified | Ready as recommendation; use official Eden video only if reuse permission is clear |

[^1]: ForestPlanet, [“Madagascar Mangrove Update”](https://forestplanet.org/madagascarmangrove04/).
[^2]: Eden: People+Planet, [“Planting Trees to Grow Forests | Eden Reforestation Projects | Vlog”](https://www.youtube.com/watch?v=XKynjGwBawE).
[^3]: Pexels, [“Man Planting Tree Free Stock Video Footage”](https://www.pexels.com/video/man-planting-tree-8544142/).
