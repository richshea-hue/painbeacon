# ForestPlanet June 10 Campaign Media Findings

## Official ForestPlanet Madagascar Mangrove Update
URL: https://forestplanet.org/madagascarmangrove04/

The page explicitly says the photographs were supplied by ForestPlanet's tree-planting partner, Eden Reforestation Projects, and focuses on mangrove restoration in the Mahajunga region of western Madagascar. This makes the page highly relevant for the June 10 launch campaign because the supplied post document specifically names ForestPlanet/Eden assets and suggests a Madagascar mangrove before/after if available.

Available page assets identified from the extracted page:

| Asset | URL | Suggested use |
|---|---|---|
| 2008 degraded mangrove site | https://forestplanet.org/wp-content/uploads/2022/02/Western-Mad-mangroves-before-2008.jpg | LinkedIn before/after split, Instagram carousel slide 1 |
| 2019 mangrove planting/community photo | https://forestplanet.org/wp-content/uploads/2022/02/Mangrove-plant-Madagascar_Mahajunga_0028-2019.08.16-smaller-1024x748.jpg | Instagram human/action option, Reel b-roll candidate if still image motion used |
| 2017 mangrove seedlings | https://forestplanet.org/wp-content/uploads/2019/08/Mangrove-seedlings-Madagascar-2017-1024x765.jpeg | Instagram carousel/detail option |
| 2020 restored mangrove site | https://forestplanet.org/wp-content/uploads/2022/02/Western-Mad-mangroves-after-2020.jpg | Facebook campaign cover image, LinkedIn before/after split, Instagram carousel slide 2 |
| Red crab/wildlife habitat image | https://forestplanet.org/wp-content/uploads/2020/12/Red-crab-cropped-with-Eden-watermark-in-Mad-2020.12.04-1024x703.jpg | Supplemental campaign storytelling, not priority for launch-day posts |

Priority recommendation so far: Use the official 2020 restored mangrove image as the Facebook campaign anchor; use the 2008/2020 pair as LinkedIn data-forward before/after; use the 2019 planting or 2017 seedlings image for Instagram if not using the before/after carousel.

## Official Eden YouTube video candidate
URL: https://www.youtube.com/watch?v=XKynjGwBawE
Title: Planting Trees to Grow Forests | Eden Reforestation Projects | Vlog
Observed from page: 7:13 video by Eden: People+Planet, visible opening shot includes nursery/planting operations and the description emphasizes local communities planting and protecting trees so they grow into healthy forests. This is relevant as a reference or link for a companion Reel concept, but any direct reuse should be limited to content the organization has rights to use or has permission from Eden to repurpose.

Recommended campaign use: If ForestPlanet/Eden has permission, cut a 15–30 second Reel from official partner footage; otherwise, use it as a creative reference and use ForestPlanet-owned stills or licensed stock clips for the actual Reel.

## Fallback stock video candidate
URL: https://www.pexels.com/video/man-planting-tree-8544142/
Title: Man Planting Tree Free Stock Video Footage, Royalty-Free 4K & HD Video Clip
Observed from page: The page labels the asset as “Free download” and “Free to use,” with tags including Conservation, Earth, Eco Friendly, Ecology, Environment, Hands, Planting, Reforestation, Sapling, Seedling, and Soil. It is a suitable fallback if no ForestPlanet/Eden-owned motion footage is available for the Instagram Reel.

Recommended campaign use: 3–5 seconds of close-up hands planting a sapling, paired with official ForestPlanet stills and a text card. Because it is generic stock, it should not be framed as a specific ForestPlanet/Eden project site.

## Visual inspection notes
The 2020 restored mangrove image is a Google Earth-style aerial/satellite view with strong project-evidence value. It is not the lushest emotional hero image, but it is excellent for a results-focused LinkedIn before/after and acceptable as a Facebook anchor if paired with the campaign copy.

The 2019 mangrove planting image is more emotionally compelling and human. It shows a worker in a restored/planting environment with warm light, young mangroves, mudflat/water context, and an Eden watermark. Excluding the blurred face, the scene is highly suitable for Instagram because it combines action, place, and visual warmth. It should be cropped with the person and seedling visible while preserving the Eden watermark where possible.

## Prepared asset validation notes
The Instagram portrait file renders the exact launch line “90 days. One mission.” clearly on a forest-green banner and preserves the official Eden planting photo, including the Eden watermark. Excluding the blurred face, the image is suitable for launch-day Instagram because the main subject is the planting scene, not the individual.

The LinkedIn before/after file is professional and evidence-forward: a clean 2008 versus 2020 split, labeled with years and a concise “Madagascar mangrove restoration” headline. This aligns with the LinkedIn post’s emphasis on verifiable, high-impact results.
