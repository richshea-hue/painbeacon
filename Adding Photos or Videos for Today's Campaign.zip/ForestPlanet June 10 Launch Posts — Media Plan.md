# ForestPlanet June 10 Launch Posts — Media Plan

This plan focuses only on the three launch posts scheduled for today: Facebook, Instagram, and LinkedIn. The strongest route is to use **official ForestPlanet/Eden-supplied Madagascar mangrove imagery** wherever possible, because the campaign copy emphasizes real trees, real soil, project outcomes, and large-scale reforestation. The official ForestPlanet Madagascar update states that the photos on that page were supplied by Eden Reforestation Projects and show mangrove restoration in the Mahajunga region of western Madagascar.[^1]

| Platform | Use this asset today | File prepared | Why this is the best fit |
|---|---|---|---|
| Facebook / GoNegative | Restored Madagascar mangroves, 2020 | `ready/facebook_campaign_anchor_madagascar_after_1200x628.jpg` | This functions as the campaign anchor image. It directly supports the “forests being reborn” line and avoids over-design. |
| Instagram feed | Human planting scene with “90 days. One mission.” | `ready/instagram_launch_portrait_planting_1080x1350.jpg` | This is the most emotionally scroll-stopping asset: warm light, real planting work, young mangroves, and an official Eden watermark. Excluding the blurred face, the subject is the restoration work, not the individual. |
| Instagram alternate | Photo-only planting square | `ready/instagram_photo_only_planting_square_1080x1080.jpg` | Use this if the feed should remain photo-only and the launch line should stay in the caption rather than on-image. |
| LinkedIn | 2008 versus 2020 Madagascar mangrove before/after | `ready/linkedin_before_after_madagascar_1200x627.jpg` | This is the most professional and evidence-forward visual. It matches the LinkedIn copy’s emphasis on verifiable, efficient, high-impact restoration. |
| Facebook alternate | Square planting image with “Something is changing.” | `ready/facebook_square_launch_planting_1080x1080.jpg` | Use this if the Facebook page favors square posts or if a more human/emotional image is preferred over the satellite restoration view. |

## Recommended video approach for today

For the optional Instagram Reel, the best direction is a **15–30 second companion Reel** that uses quick cuts: official ForestPlanet/Eden stills, a planting close-up, restored mangrove aerial/satellite proof, and a final donation CTA. Eden’s official YouTube video, “Planting Trees to Grow Forests,” is highly relevant as a reference and may be usable if ForestPlanet already has permission to repurpose Eden partner footage.[^2] If permission is not already clear, use it only as a creative reference.

| Reel segment | Visual | Source recommendation | On-screen text |
|---|---|---|---|
| 0–3 sec | Restored mangrove or seedling detail | ForestPlanet/Eden official still | `The campaign starts today.` |
| 3–8 sec | Hands/worker planting mangrove seedlings | Official still or permitted Eden clip | `90 days. One mission.` |
| 8–14 sec | Before/after restoration proof | Official Madagascar 2008/2020 imagery | `$1 plants 6+ trees.` |
| 14–20 sec | Green mangrove / restored site | Official still | `Plant trees where they matter most.` |
| 20–30 sec | Simple CTA card | Forest green background | `forestplanet.org/donate` |

A fallback stock video option is Pexels’ “Man Planting Tree,” which is labeled “Free download” and “Free to use” on the asset page.[^3] It fits a general planting close-up, but because it is generic stock, it should **not** be described as a ForestPlanet or Eden project site.

## Source and usage notes

The official ForestPlanet page is the preferred source for launch-day imagery because it explicitly connects the visuals to ForestPlanet’s Eden partnership and to Madagascar mangrove restoration.[^1] The Pexels clip is a fallback only; it can provide motion if no partner footage is available, but the campaign should prioritize owned or partner-approved assets for credibility.

[^1]: ForestPlanet, [“Madagascar Mangrove Update”](https://forestplanet.org/madagascarmangrove04/).
[^2]: Eden: People+Planet, [“Planting Trees to Grow Forests | Eden Reforestation Projects | Vlog”](https://www.youtube.com/watch?v=XKynjGwBawE).
[^3]: Pexels, [“Man Planting Tree Free Stock Video Footage”](https://www.pexels.com/video/man-planting-tree-8544142/).
