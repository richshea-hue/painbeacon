#!/usr/bin/env python3
import sys, zipfile, xml.etree.ElementTree as ET
from pathlib import Path

path = Path(sys.argv[1])
out = Path(sys.argv[2])
ns = {'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with zipfile.ZipFile(path) as z:
    xml = z.read('word/document.xml')
root = ET.fromstring(xml)
lines=[]
for p in root.findall('.//w:p', ns):
    texts=[]
    for node in p.iter():
        if node.tag == '{%s}t' % ns['w'] and node.text:
            texts.append(node.text)
        elif node.tag == '{%s}tab' % ns['w']:
            texts.append('\t')
        elif node.tag == '{%s}br' % ns['w']:
            texts.append('\n')
    line=''.join(texts).strip()
    if line:
        lines.append(line)
out.write_text('\n'.join(lines)+'\n', encoding='utf-8')
print(f'Wrote {out} with {len(lines)} non-empty paragraphs')
