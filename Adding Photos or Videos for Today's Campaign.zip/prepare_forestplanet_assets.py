#!/usr/bin/env python3
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path

ROOT = Path('/home/ubuntu/forestplanet_june10_media')
ORIG = ROOT / 'originals'
READY = ROOT / 'ready'
READY.mkdir(parents=True, exist_ok=True)

GREEN = (25, 111, 61)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

try:
    FONT_BOLD = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 52)
    FONT_MED = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 42)
    FONT_SMALL = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 32)
except Exception:
    FONT_BOLD = FONT_MED = FONT_SMALL = ImageFont.load_default()


def cover_crop(img, size, focus=(0.5,0.5)):
    target_w, target_h = size
    iw, ih = img.size
    scale = max(target_w/iw, target_h/ih)
    nw, nh = int(round(iw*scale)), int(round(ih*scale))
    img = img.resize((nw, nh), Image.LANCZOS)
    fx, fy = focus
    left = int((nw-target_w)*fx)
    top = int((nh-target_h)*fy)
    left = max(0, min(left, nw-target_w))
    top = max(0, min(top, nh-target_h))
    return img.crop((left, top, left+target_w, top+target_h))


def draw_label(draw, xy, text, font, fill=WHITE, bg=GREEN, pad=16):
    x, y = xy
    bbox = draw.textbbox((x, y), text, font=font)
    rect = (x-pad, y-pad, bbox[2]+pad, bbox[3]+pad)
    draw.rounded_rectangle(rect, radius=10, fill=bg)
    draw.text((x, y), text, fill=fill, font=font)

# Facebook landscape anchor from the official restored mangrove image
after = Image.open(ORIG / 'madagascar_mangroves_after_2020.jpg').convert('RGB')
fb = cover_crop(after, (1200, 628), focus=(0.5,0.48))
fb.save(READY / 'facebook_campaign_anchor_madagascar_after_1200x628.jpg', quality=92)

# Instagram portrait with blurred background preserving full planting image
planting = Image.open(ORIG / 'madagascar_mangrove_planting_2019.jpg').convert('RGB')
canvas_size = (1080, 1350)
bg = cover_crop(planting, canvas_size, focus=(0.58,0.48)).filter(ImageFilter.GaussianBlur(28))
overlay = Image.new('RGBA', canvas_size, (0,0,0,40))
bg = Image.alpha_composite(bg.convert('RGBA'), overlay).convert('RGB')
# fit original photo within portrait canvas, leaving room-like margins
scale = min(1000/planting.width, 930/planting.height)
new_size = (int(planting.width*scale), int(planting.height*scale))
fg = planting.resize(new_size, Image.LANCZOS)
x = (canvas_size[0]-new_size[0])//2
y = (canvas_size[1]-new_size[1])//2 - 10
bg.paste(fg, (x,y))
# Add unobtrusive title band per campaign direction
ig = bg.convert('RGBA')
draw = ImageDraw.Draw(ig)
draw.rounded_rectangle((60, 60, 1020, 180), radius=20, fill=(25,111,61,218))
draw.text((100, 86), '90 days. One mission.', fill=WHITE, font=FONT_BOLD)
ig.convert('RGB').save(READY / 'instagram_launch_portrait_planting_1080x1350.jpg', quality=92)

# Instagram square photo-only option from the same planting image
ig_sq = cover_crop(planting, (1080,1080), focus=(0.62,0.48))
ig_sq.save(READY / 'instagram_photo_only_planting_square_1080x1080.jpg', quality=92)

# LinkedIn before/after split
before = Image.open(ORIG / 'madagascar_mangroves_before_2008.jpg').convert('RGB')
left = cover_crop(before, (600, 627), focus=(0.5,0.5))
right = cover_crop(after, (600, 627), focus=(0.5,0.5))
li = Image.new('RGB', (1200, 627), WHITE)
li.paste(left, (0,0)); li.paste(right, (600,0))
draw = ImageDraw.Draw(li)
# subtle center divider
draw.rectangle((592, 0, 608, 627), fill=WHITE)
draw.rectangle((0, 0, 1200, 80), fill=(0,0,0))
draw.text((40, 18), 'Madagascar mangrove restoration', fill=WHITE, font=FONT_MED)
draw_label(draw, (50, 535), '2008', FONT_SMALL, bg=(91,65,45))
draw_label(draw, (650, 535), '2020', FONT_SMALL, bg=GREEN)
li.save(READY / 'linkedin_before_after_madagascar_1200x627.jpg', quality=92)

# Facebook square fallback using planting image with minimal overlay
fb_sq = cover_crop(planting, (1080,1080), focus=(0.55,0.5))
draw = ImageDraw.Draw(fb_sq)
draw.rounded_rectangle((50, 50, 780, 150), radius=18, fill=(25,111,61,218))
draw.text((80, 78), 'Something is changing.', fill=WHITE, font=FONT_MED)
fb_sq.save(READY / 'facebook_square_launch_planting_1080x1080.jpg', quality=92)

print('Created ready assets:')
for p in sorted(READY.glob('*.jpg')):
    im = Image.open(p)
    print(f'{p.name}\t{im.size[0]}x{im.size[1]}')
